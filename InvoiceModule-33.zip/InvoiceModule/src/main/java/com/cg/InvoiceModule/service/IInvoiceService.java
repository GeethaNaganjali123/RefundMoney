package com.cg.InvoiceModule.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.InvoiceModule.bean.Invoice;
import com.cg.InvoiceModule.exception.InvoiceException;



public interface IInvoiceService {
	
	public List<Invoice> getInvoice(int id)throws InvoiceException;
	public double getInvoiceb(int id)throws InvoiceException;
	
	public List<Invoice> addProduct(@Valid Invoice pro)throws InvoiceException;
	public List<Invoice> getAllProducts()throws InvoiceException;

}
