package com.cg.InvoiceModule.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.InvoiceModule.bean.Invoice;

@Repository
public interface IInvoiceDao extends JpaRepository<Invoice, Integer> {
	
	@Query(value="SELECT * FROM invoice WHERE cust_id=:u",nativeQuery=true)
	List<Invoice> findAll(@Param("u") Integer id);
//	@Query(value="SELECT SUM(prod_price) FROM invoice where cust_id=:u",nativeQuery=true)
//	double sum(@Param("u") Integer id);

	@Query(value="SELECT SUM(discounted_price) FROM invoice where cust_id=:u",nativeQuery=true)
	double sum(@Param("u") Integer id);
	
	
}
