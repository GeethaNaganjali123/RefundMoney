package com.cg.RefundMoney.service;

import java.util.List;


import com.cg.RefundMoney.bean.Order;




public interface IRefundService {
	
	public List<Order> getAllProducts();
	public Order getProductById(int orderId);
    public Order checkstatus(int orderid);
	public boolean refundMoney(int orderId);
	
}
