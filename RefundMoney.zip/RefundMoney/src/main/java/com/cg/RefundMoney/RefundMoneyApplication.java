package com.cg.RefundMoney;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefundMoneyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefundMoneyApplication.class, args);
	}

}
