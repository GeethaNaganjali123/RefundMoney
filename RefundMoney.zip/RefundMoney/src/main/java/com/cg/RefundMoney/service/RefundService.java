package com.cg.RefundMoney.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.RefundMoney.bean.Order;
import com.cg.RefundMoney.dao.IRefundDao;

@Service
public class RefundService implements IRefundService {
	
	@Autowired
    IRefundDao iRefundDao;

	@Override
	public List<Order> getAllProducts() {
		return iRefundDao.findAll();
	}

	@Override
	public Order getProductById(int orderId) {
		return iRefundDao.findById(orderId).get();
	}
	@Override
	public Order checkstatus(int orderid) {
		Order myorder=iRefundDao.findById(orderid).get();
		List<Order> prodreturn = iRefundDao.findAll();
		for(Order ret:prodreturn)
		{
			
			if(ret.getOrderId()==orderid)
			{
				return ret;
			}
		}
		
		return null;
	}

	@Override
	public boolean refundMoney(int orderId) {
		
		int price = (int) getProductById(orderId).getProductPrice();
		
		Order ord=new Order();
		double customerwallet= ord.getCustomerwallet()+price;
		ord.setCustomerwallet(customerwallet);
		return false;
	}

	

}
