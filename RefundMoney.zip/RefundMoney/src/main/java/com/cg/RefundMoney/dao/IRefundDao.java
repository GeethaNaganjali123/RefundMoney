package com.cg.RefundMoney.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.RefundMoney.bean.Order;




@Repository
public interface IRefundDao extends JpaRepository<Order, Integer>{
	
	@Query("from Order where orderid = :c")
	Optional<Order> findById(@Param("c") int orderid);

}
